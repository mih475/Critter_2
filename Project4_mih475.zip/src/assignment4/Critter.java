package assignment4;
/* CRITTERS Critter.java
 * EE422C Project 4 submission by
 * Muhammad Ishraq Hasan
 * mih475
 * 15500
 * Slip days used: <0>
 * Spring 2018
 */


import javafx.util.Pair;

import java.util.*;

/* see the PDF for descriptions of the methods and fields in this class
 * you may add fields, methods or inner classes to Critter ONLY if you make your additions private
 * no new public, protected or default-package code or data can be added to Critter
 */


public abstract class Critter {
	private static String myPackage;
	private	static List<Critter> population = new java.util.ArrayList<Critter>();
	private static List<Critter> babies = new java.util.ArrayList<Critter>();

	// Gets the package name.  This assumes that Critter and its subclasses are all in the same package.
	static {
		myPackage = Critter.class.getPackage().toString().split(" ")[1];
	}
	
	private static java.util.Random rand = new java.util.Random();
	public static int getRandomInt(int max) {
		return rand.nextInt(max);
	}
	
	public static void setSeed(long new_seed) {
		rand = new java.util.Random(new_seed);
	}
	
	
	/* a one-character long string that visually depicts your critter in the ASCII interface */
	public String toString() { return ""; }
	
	private int energy = 0;

	/**
	 * @return energy of current critter
	 */
	protected int getEnergy() { return energy; }
	
	private int x_coord;
	private int y_coord;


	/**
	 * Private function used by walk function. It increases current critter's x_coord by 1.
	 */
	private void increase_x_coord(){
		x_coord = x_coord+1;
	}

	/**
	 * Private function used by walk function. It decreases current critter's x_coord by 1.
	 */
	private void decrese_x_coord(){
		x_coord = x_coord-1;
	}

	/**
	 * Private function used by walk function. It increases current critter's y_coord by 1.
	 */
	private void increase_y_coord(){
		y_coord = y_coord+1;
	}

	/**
	 * Private function used by walk function. It decreases current critter's y_coord by 1.
	 */
	private void decrease_y_coord(){
		y_coord = y_coord-1;
	}

	/**
	 * Private function used by walk function. If x_coord is positively out of bound then
	 * it puts back to its correct place.
	 */
	private void positive_out_of_bound_x_coord(){
		x_coord = x_coord % Params.world_width;
	}

	/**
	 * Private function used by walk function. If x_coord is negetively out of bound then
	 * it puts back to its correct place.
	 */
	private void negetive_out_of_bound_x_coord(){
		x_coord = x_coord + Params.world_width;
	}

	/**
	 * Private function used by walk function. If y_coord is positively out of bound then
	 * it puts back to its correct place.
	 */
	private void positive_out_of_bound_y_coord(){
		y_coord = y_coord % Params.world_height;
	}

	/**
	 * Private function used by walk function. If y_coord is negetively out of bound then
	 * it puts back to its correct place.
	 */
	private void negetive_out_of_bound_y_coord(){
		y_coord = y_coord + Params.world_height;
	}

	/**
	 * Private function used by walk function. It checks if x_coord is out of bound or not.
	 */
	private void check_x_coord(){
		if(x_coord == Params.world_width){
			positive_out_of_bound_x_coord();
		}
		else if(x_coord < 0){
			negetive_out_of_bound_x_coord();
		}
	}

	/**
	 * Private function used by walk function. It checks if y_coord is out of bound or not.
	 */
	private void check_y_coord(){
		if(y_coord == Params.world_height){
			positive_out_of_bound_y_coord();
		}
		else if(y_coord < 0){
			negetive_out_of_bound_y_coord();
		}
	}


	/**
	 * This method helps Critters to walk. It has several helper functions.
	 * @param direction
	 */
	protected final void walk(int direction) {
		if(direction == 0) {
			increase_x_coord();
			check_x_coord();
		}
		else if(direction == 1) {
			increase_x_coord();
			check_x_coord();
			increase_y_coord();
			check_y_coord();
		}
		else if(direction == 2){
			increase_y_coord();
			check_y_coord();
		}
		else if(direction == 3){
			decrese_x_coord();
			check_x_coord();
			increase_y_coord();
			check_y_coord();
		}
		else if(direction == 4){
			decrese_x_coord();
			check_x_coord();
		}
		else if(direction == 5){
			decrese_x_coord();
			check_x_coord();
			decrease_y_coord();
			check_y_coord();
		}
		else if(direction == 6){
			decrease_y_coord();
			check_y_coord();
		}
		else if(direction == 7){
			increase_x_coord();
			check_x_coord();
			decrease_y_coord();
			check_y_coord();
		}
		energy = energy - Params.walk_energy_cost;
	}


	/**
	 * This method helps Critters to run
	 * @param direction
	 */
	protected final void run(int direction) {
		walk(direction);
		walk(direction);
		energy = energy + (2*Params.walk_energy_cost);
		energy = energy - Params.run_energy_cost;
	}


	/**
	 * This method produces babies if current Critter's energy is Params.min_reproduce_energy or higher.
	 * It uses direction parameter to set the location of the baby.
	 * At the end, that baby is added to the list of babies.
	 * @param offspring
	 * @param direction
	 */
	protected final void reproduce(Critter offspring, int direction) {
		if(energy >= Params.min_reproduce_energy){
			offspring.energy = energy/2;
			energy = (energy+1)/2;
			if(direction == 0){
				offspring.x_coord = x_coord+1;
			}
			else if(direction == 1){
				offspring.x_coord = x_coord + 1;
				offspring.y_coord = y_coord + 1;
			}
			else if(direction == 2){
				offspring.y_coord = y_coord+1;
			}
			else if(direction == 3){
				offspring.x_coord = x_coord - 1;
				offspring.y_coord = y_coord+1;
			}
			else if(direction == 4){
				offspring.x_coord = x_coord-1;
			}
			else if(direction == 5){
				offspring.x_coord = x_coord-1;
				offspring.y_coord = y_coord-1;
			}
			else if(direction == 6){
				offspring.y_coord = y_coord-1;
			}
			else if(direction == 7){
				offspring.x_coord = x_coord+1;
				offspring.y_coord = y_coord-1;
			}
			offspring.x_coord = (Params.world_width+offspring.x_coord) % Params.world_width;
			offspring.y_coord = (Params.world_height+offspring.y_coord) % Params.world_height;
			babies.add(offspring);
		}
	}

	public abstract void doTimeStep();
	public abstract boolean fight(String oponent);
	
	/**
	 * create and initialize a Critter subclass.
	 * critter_class_name must be the unqualified name of a concrete subclass of Critter, if not,
	 * an InvalidCritterException must be thrown.
	 * (Java weirdness: Exception throwing does not work properly if the parameter has lower-case instead of
	 * upper. For example, if craig is supplied instead of Craig, an error is thrown instead of
	 * an Exception.)
	 * @param critter_class_name
	 * @throws InvalidCritterException
	 */
	public static void makeCritter(String critter_class_name) throws InvalidCritterException {

		try {
			Class<?> cl = Class.forName("assignment4." + critter_class_name);
			Critter cr = (Critter) cl.newInstance();
			cr.x_coord = getRandomInt(Params.world_width);
			cr.y_coord = getRandomInt(Params.world_height);
			cr.energy = Params.start_energy;
			population.add(cr);
		}
		catch (ClassNotFoundException e){
			throw new InvalidCritterException(critter_class_name);
		}
		catch (InstantiationException e){
			throw new InvalidCritterException(critter_class_name);
		}
		catch(IllegalAccessException e){
			throw new InvalidCritterException(critter_class_name);
		}

	}
	
	/**
	 * Gets a list of critters of a specific type.
	 * @param critter_class_name What kind of Critter is to be listed.  Unqualified class name.
	 * @return List of Critters.
	 * @throws InvalidCritterException
	 */
	public static List<Critter> getInstances(String critter_class_name) throws InvalidCritterException {
		List<Critter> result = new java.util.ArrayList<Critter>();

		try{
			Class<?> cl = Class.forName("assignment4." +critter_class_name);
			for(Critter cr : population){
					if(cl.isInstance(cr)){
						result.add(cr);
					}
			}
			return result;
		}
		catch (ClassNotFoundException e){
			throw new InvalidCritterException(critter_class_name);
		}

	}
	
	/**
	 * Prints out how many Critters of each type there are on the board.
	 * @param critters List of Critters.
	 */
	public static void runStats(List<Critter> critters) {
		System.out.print("" + critters.size() + " critters as follows -- ");
		java.util.Map<String, Integer> critter_count = new java.util.HashMap<String, Integer>();
		for (Critter crit : critters) {
			String crit_string = crit.toString();
			Integer old_count = critter_count.get(crit_string);
			if (old_count == null) {
				critter_count.put(crit_string,  1);
			} else {
				critter_count.put(crit_string, old_count.intValue() + 1);
			}
		}
		String prefix = "";
		for (String s : critter_count.keySet()) {
			System.out.print(prefix + s + ":" + critter_count.get(s));
			prefix = ", ";
		}
		System.out.println();		
	}
	
	/* the TestCritter class allows some critters to "cheat". If you want to 
	 * create tests of your Critter model, you can create subclasses of this class
	 * and then use the setter functions contained here. 
	 * 
	 * NOTE: you must make sure that the setter functions work with your implementation
	 * of Critter. That means, if you're recording the positions of your critters
	 * using some sort of external grid or some other data structure in addition
	 * to the x_coord and y_coord functions, then you MUST update these setter functions
	 * so that they correctly update your grid/data structure.
	 */
	static abstract class TestCritter extends Critter {
		protected void setEnergy(int new_energy_value) {
			super.energy = new_energy_value;
		}
		
		protected void setX_coord(int new_x_coord) {
			super.x_coord = new_x_coord;
		}
		
		protected void setY_coord(int new_y_coord) {
			super.y_coord = new_y_coord;
		}
		
		protected int getX_coord() {
			return super.x_coord;
		}
		
		protected int getY_coord() {
			return super.y_coord;
		}
		

		/*
		 * This method getPopulation has to be modified by you if you are not using the population
		 * ArrayList that has been provided in the starter code.  In any case, it has to be
		 * implemented for grading tests to work.
		 */
		protected static List<Critter> getPopulation() {
			return population;
		}
		
		/*
		 * This method getBabies has to be modified by you if you are not using the babies
		 * ArrayList that has been provided in the starter code.  In any case, it has to be
		 * implemented for grading tests to work.  Babies should be added to the general population 
		 * at either the beginning OR the end of every timestep.
		 */
		protected static List<Critter> getBabies() {
			return babies;
		}

		/**
		 * This method gets the current location of the critter and determines if there is any empty spot
		 * to run away from fight
		 * The process is -
		 * 			For each direction, it will check if there is a critter in the targeted location and
		 * 			it will count how many times that location was empty. If that count is equal to the size
		 * 			of the population, then that spot is empty and the critter can run away to that spot.
		 *
		 * 			If one direction fails, then it will keep checking for another direction until all
		 * 			directions have been checked.
		 *
		 * 			If all fail, then there is no way to run. It will return a unrelated value.
		 * @param x x_coord of the critter
		 * @param y y_coord of the critter
		 * @return position, that the critter will take after looking for an empty spot to run away.
		 */
		protected int position_taken(int x, int y){
			int no_way_to_run = 10;
			int count = 0;
			for(int i = 0;i< population.size();i++){
				if(population.get(i).x_coord != x+2 || population.get(i).y_coord != y){
					count++;
				}
				if(count == population.size()){
					return 0;
				}
			}
			count = 0;
			for(int i = 0;i< population.size();i++){
				if(population.get(i).x_coord != x+2 || population.get(i).y_coord != y+2){
					count++;
				}
				if(count == population.size()){
					return 1;
				}
			}
			count = 0;
			for(int i = 0;i< population.size();i++){
				if(population.get(i).x_coord != x || population.get(i).y_coord != y+2){
					count++;
				}
				if(count == population.size()){
					return 2;
				}
			}
			count = 0;
			for(int i = 0;i< population.size();i++){
				if(population.get(i).x_coord != x-2 || population.get(i).y_coord != y+2){
					count++;
				}
				if(count == population.size()){
					return 3;
				}
			}
			count = 0;
			for(int i = 0;i< population.size();i++){
				if(population.get(i).x_coord != x-2 || population.get(i).y_coord != y){
					count++;
				}
				if(count == population.size()){
					return 4;
				}
			}
			count = 0;
			for(int i = 0;i< population.size();i++){
				if(population.get(i).x_coord != x-2 || population.get(i).y_coord != y-2){
					count++;
				}
				if(count == population.size()){
					return 5;
				}
			}
			count = 0;
			for(int i = 0;i< population.size();i++){
				if(population.get(i).x_coord != x || population.get(i).y_coord != y-2){
					count++;
				}
				if(count == population.size()){
					return 6;
				}
			}
			count = 0;
			for(int i = 0;i< population.size();i++){
				if(population.get(i).x_coord != x+2 || population.get(i).y_coord != y-2){
					count++;
				}
				if(count == population.size()){
					return 7;
				}
			}
			return no_way_to_run;
		}
	}

	/**
	 * Clear the world of all critters, dead and alive
	 */
	public static void clearWorld() {
		population.clear();
		babies.clear();
	}

	/**
	 * Private method for fights between Critters in the same location
	 *
	 * if both critters want to fight and they are in the same location, random amount of energy from both critters
	 * will be compared - higher value will win and take loser's half of the energy and loser will die. If compared
	 * energy is equal, then one random critter will be winner and other one will die.
	 *
	 * if one critter wants to fight and other doesn't and not able to run away, then fight one will win by default
	 *
	 * if both critters refuse to fight and unable to run away, then one will be winner randomly.
	 */
	private static void fight_between_critters(){
		for(int x = 0; x<population.size(); x++){
			for(int y = x+1; y <population.size(); y++){
				while(population.get(x).energy <= 0 || population.get(y).energy <= 0){
					if(population.get(x).energy <= 0){
						population.remove(population.get(x));
					}
					else{
						population.remove(population.get(y));
					}
					if(population.size()<x+1 || population.size()<y+1){
						break;
					}
				}
				if(population.size()<x+1 || population.size()<y+1){
					break;
				}
				int power_used_in_fight_by_x = 0;
				int power_used_in_fight_by_y = 0;
				int x_coord_for_x_after_time_step = population.get(x).x_coord;
				int x_coord_for_y_after_time_step = population.get(y).x_coord;
				int y_coord_for_x_after_time_step = population.get(x).y_coord;
				int y_coord_for_y_after_time_step = population.get(y).y_coord;
				if((x_coord_for_x_after_time_step == x_coord_for_y_after_time_step) &&
						(y_coord_for_x_after_time_step == y_coord_for_y_after_time_step)){
					boolean does_1st_critter_wants_to_fight_with_2nd_critter = population.get(x).fight(population.get(y).toString());
					boolean does_2nd_critter_wants_to_fight_with_1st_critter = population.get(y).fight(population.get(x).toString());
					if(does_1st_critter_wants_to_fight_with_2nd_critter && does_2nd_critter_wants_to_fight_with_1st_critter){
						if(x_coord_for_x_after_time_step == population.get(x).x_coord && y_coord_for_x_after_time_step == population.get(x).y_coord){
							if(x_coord_for_y_after_time_step == population.get(y).x_coord && y_coord_for_y_after_time_step == population.get(y).y_coord){
								power_used_in_fight_by_x = getRandomInt(population.get(x).energy);
								power_used_in_fight_by_y = getRandomInt(population.get(y).energy);
								if(power_used_in_fight_by_x > power_used_in_fight_by_y){
									population.get(x).energy = population.get(x).energy + (population.get(y).energy/2);
									population.get(y).energy = 0;
									population.remove(population.get(y));
								}
								else if (power_used_in_fight_by_x < power_used_in_fight_by_y){
									population.get(y).energy = population.get(y).energy + (population.get(x).energy/2);
									population.get(x).energy = 0;
									population.remove(population.get(x));
									break;
								}
								else if(power_used_in_fight_by_x == power_used_in_fight_by_y){
									int lottery = getRandomInt(2);
									if(lottery == 0){
										population.get(x).energy = population.get(x).energy + (population.get(y).energy/2);
										population.get(y).energy = 0;
										population.remove(population.get(y));
									}
									else{
										population.get(y).energy = population.get(y).energy + (population.get(x).energy/2);
										population.get(x).energy = 0;
										population.remove(population.get(x));
										break;
									}
								}
							}
						}
					}
					else if(does_1st_critter_wants_to_fight_with_2nd_critter || does_2nd_critter_wants_to_fight_with_1st_critter) {
						if (x_coord_for_x_after_time_step == population.get(x).x_coord && y_coord_for_x_after_time_step == population.get(x).y_coord) {
							if (x_coord_for_y_after_time_step == population.get(y).x_coord && y_coord_for_y_after_time_step == population.get(y).y_coord) {
								if (does_1st_critter_wants_to_fight_with_2nd_critter) {
									population.get(x).energy = population.get(x).energy + (population.get(y).energy / 2);
									population.get(y).energy = 0;
									population.remove(population.get(y));
								} else {
									population.get(y).energy = population.get(y).energy + (population.get(x).energy / 2);
									population.get(x).energy = 0;
									population.remove(population.get(x));
									break;
								}
							}
						}
					}
					else{
						if (x_coord_for_x_after_time_step == population.get(x).x_coord && y_coord_for_x_after_time_step == population.get(x).y_coord) {
							if (x_coord_for_y_after_time_step == population.get(y).x_coord && y_coord_for_y_after_time_step == population.get(y).y_coord) {
								while(population.get(x).energy <= 0 || population.get(y).energy <= 0){
									if(population.get(x).energy <= 0){
										population.remove(population.get(x));
									}
									else{
										population.remove(population.get(y));
									}
									if(population.size()<x+1 || population.size()<y+1){
										break;
									}
								}
								if(population.size()<x+1 || population.size()<y+1){
									break;
								}
								int lottery = getRandomInt(2);
								if(lottery == 0){
									population.get(x).energy = population.get(x).energy + (population.get(y).energy/2);
									population.get(y).energy = 0;
									population.remove(population.get(y));
								}
								else{
									population.get(y).energy = population.get(y).energy + (population.get(x).energy/2);
									population.get(x).energy = 0;
									population.remove(population.get(x));
									break;
								}
							}
						}
					}
				}
			}
		}
	}


	/**
	 * worldTimeStep performs following tasks respectively -
	 * 1. Perform doTimeStep method for every Critter in the population list
	 * 2. Do the fights
	 * 3. updateRestEnergy();
	 * 4. Generate Algae
	 * 5. Move babies to general population. population.addAll(babies); babies.clear();
	 * 6. Remove any dead Critter
	 */
	public static void worldTimeStep() {

		for(int i = 0; i<population.size(); i++){
			population.get(i).doTimeStep();
		}

		fight_between_critters();

		for(int i = 0; i < population.size(); i++){
			population.get(i).energy = population.get(i).energy - Params.rest_energy_cost;
		}
		for(int i = 0; i < Params.refresh_algae_count; i++){
			Algae a = new Algae();
			a.setEnergy(Params.start_energy);
			a.setX_coord(getRandomInt(Params.world_width));
			a.setY_coord(getRandomInt(Params.world_height));
			population.add(a);
		}
		population.addAll(babies);
		babies.clear();
		for(int i = 0; i < population.size(); i++){
			if(population.get(i).energy <= 0){
				population.remove(population.get(i));
			}
		}
	}

	/**
	 * It displays a 2D world with Critters or without Critters depending on the command input.
	 */
	public static void displayWorld() {
		int width_with_border = Params.world_width + 2;
		int height_with_border = Params.world_height + 2;
		char[][] world = new char[height_with_border][width_with_border];

		for(int i = 0; i<height_with_border; i++){
			for(int j = 0; j<width_with_border; j++){
				if(i == 0 || i == height_with_border-1){
					if(j == 0 || j == width_with_border-1){
						world[i][j] = '+';
					}
					else{
						world[i][j] = '-';
					}
				}
				else {
					if(j==0 || j == width_with_border-1){
						world[i][j] = '|';
					}
					else {
						world[i][j] = ' ';
					}
				}
			}
		}
		for(Critter c : population){
			int x = c.x_coord + 1;
			int y = c.y_coord + 1;
			world[y][x] = c.toString().charAt(0);
		}
		String each_line = new String();
		for(int k = 0; k<height_with_border; k++){
			for(int m = 0; m< width_with_border; m++){
				each_line = each_line + (world[k][m]);
			}
			System.out.println(each_line);
			each_line = "";
		}
	}


}
