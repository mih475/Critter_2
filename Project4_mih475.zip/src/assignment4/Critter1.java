package assignment4;

/* CRITTERS Critter.java
 * EE422C Project 4 submission by
 * Muhammad Ishraq Hasan
 * mih475
 * 15500
 * Slip days used: <0>
 * Spring 2018
 */


/* This critter acts like an animal(carnivorous).
 * It can reproduce when it's energy is really high.
 * It will only walk. It never runs.
 * It will attack Critter2(herbivorous) and Algae even if it has very low energy.
 * For other unknown creatures, it will only attack when it's energy is 80 or higher. Otherwise it won't fight.
 */
import java.util.*;

public class Critter1 extends Critter {

	private int dir;

	/* Constructor
	 * It constructs value for dir(used for selecting the walking direction) and walk_or_not(randomly decides if
	 * Critter1 will walk or not during TimeStep)
	 */
	public Critter1(){
		dir = getRandomInt(8);
	}

	/**
	 * TimeStep function - it walks. It will reproduce if energy is 130 or higher
	 */
	@Override
	public void doTimeStep() {
		walk(dir);
		if(super.getEnergy()>= 130){
			Critter1 child = new Critter1();
			super.reproduce(child, getRandomInt(8));
		}

	}

	/**
	 * This function decides if the critter will fight or not
	 * @param opponent
	 * @return true if it faces Algae or Critter2 and energy is 30 or higher. true for any other
	 * creature only if energy is 80 or higher. false otherwise
	 */
	@Override
	public boolean fight(String opponent) {
		if (getEnergy() >= 30 && (opponent.equals("2") || opponent.equals("@"))){
			return true;
		}
		if(getEnergy() >= 80){
			return true;
		}
		return false;
	}

	/**
	 * @return String representing the Critter
	 */
	@Override
	public String toString() {
		return "1";
	}

}
