package assignment4;

/* CRITTERS Critter.java
 * EE422C Project 4 submission by
 * Muhammad Ishraq Hasan
 * mih475
 * 15500
 * Slip days used: <0>
 * Spring 2018
 */

/* This critter acts like an animal(herbivorous).
 * It can reproduce when it's energy is really high.
 * It randomly walks or stay in the same place.
 * It will only attack when it faces Algae or Craig.
 * Otherwise it won't fight but will try to escape by running.
 */


import assignment4.Critter.TestCritter;

public class Critter2 extends TestCritter {

	private int walk_or_not;
	private int dir;

	/* Constructor
	 * It constructs value for dir(used for selecting the walking direction) and walk_or_not(randomly decides if
	 * Critter1 will walk or not during TimeStep)
	 */
	public Critter2(){
		dir = getRandomInt(8);
		walk_or_not = getRandomInt(2);
	}

	/**
	 * TimeStep function - it may walk or stay at the same place. It will reproduce if energy is 140 or higher
	 */
	@Override
	public void doTimeStep() {
		if(walk_or_not == 1){
			walk(dir);
		}
		if(super.getEnergy()>= 140){
			Critter2 child = new Critter2();
			super.reproduce(child, getRandomInt(8));
		}

	}

	/**
	 * This function decides if the critter will fight or not
	 * @param opponent
	 * @return true if it faces Algae or Craig. False otherwise.
	 */
	@Override
	public boolean fight(String opponent) {

		if(opponent.equals("@") || opponent.equals("C")){
			return true;
		}

		else if(walk_or_not != 1){
			int x = super.getX_coord();
			int y = super.getY_coord();
			int position_taken = super.position_taken(x,y);
			if(position_taken < 10){
				run(position_taken);
			}
			return false;
		}
		return false;
	}

	/**
	 * @return String representing the Critter
	 */
	@Override
	public String toString () {
		return "2";
	}
}
